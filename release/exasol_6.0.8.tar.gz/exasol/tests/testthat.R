library(testthat)
library(exasol)

test_check("exasol")
